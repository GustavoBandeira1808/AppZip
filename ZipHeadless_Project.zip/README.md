# ZipHeadless (Android, sem interface)

Utilitário **headless** para compactar arquivos/pastas no Android. Pode ser chamado via terminal/scripts.

## Comandos de exemplo

Zipar pasta inteira (conteúdo interno):
```
am start-foreground-service -n com.ziptool.headless/.ZipService   --es origem "/storage/emulated/0/MinhaPasta"   --es destino "/storage/emulated/0/saida.zip"
```

Zipar incluindo a pasta raiz:
```
am start-foreground-service -n com.ziptool.headless/.ZipService   --es origem "/storage/emulated/0/MinhaPasta"   --es destino "/storage/emulated/0/saida.zip"   --es modo "raiz"
```

Múltiplas origens:
```
am start-foreground-service -n com.ziptool.headless/.ZipService   --es origem "/sdcard/A::/sdcard/B/file.txt"   --es destino "/sdcard/mix.zip"
```
