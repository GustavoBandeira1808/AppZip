package com.ziptool.headless

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import java.io.File

class ZipService : Service() {

    companion object {
        private const val TAG = "ZipHeadless"
        private const val CHANNEL_ID = "zip_headless_channel"
        const val EXTRA_INPUT = "origem"
        const val EXTRA_OUTPUT = "destino"
        const val EXTRA_INCLUDE_ROOT = "incluirRaiz"
        const val EXTRA_OVERWRITE = "sobrescrever"
        const val EXTRA_MODE = "modo"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Compactando...")
            .setContentText("ZipHeadless em execução")
            .setOngoing(true)
            .build()
        startForeground(1, notif)

        Thread {
            try {
                runZipping(intent)
                showDone("Concluído")
            } catch (e: Exception) {
                Log.e(TAG, "Erro", e)
                showDone("Erro: ${e.message}")
            } finally {
                stopSelf()
            }
        }.start()

        return START_NOT_STICKY
    }

    private fun runZipping(intent: Intent?) {
        requireNotNull(intent) { "Intent nula" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                val settingsIntent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                settingsIntent.data = Uri.parse("package:$packageName")
                settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(settingsIntent)
                throw SecurityException("Conceda 'Gerenciar todos os arquivos' ao app e tente novamente.")
            }
        }
        val inputRaw = intent.getStringExtra(EXTRA_INPUT) ?: throw IllegalArgumentException("Extra 'origem' ausente")
        val outputPath = intent.getStringExtra(EXTRA_OUTPUT) ?: throw IllegalArgumentException("Extra 'destino' ausente")
        val includeRoot = intent.getBooleanExtra(EXTRA_INCLUDE_ROOT, false) ||
            (intent.getStringExtra(EXTRA_MODE)?.equals("raiz", true) == true)
        val overwrite = intent.getBooleanExtra(EXTRA_OVERWRITE, true)
        val inputs = inputRaw.split("::").map { File(it.trim()) }.filter { it.path.isNotBlank() }
        if (inputs.isEmpty()) throw IllegalArgumentException("Nenhuma origem válida")
        val out = File(outputPath)
        Log.i(TAG, "Zipping ${inputs.size} entradas → ${out.absolutePath}, includeRoot=$includeRoot overwrite=$overwrite")
        ZipUtils.zip(inputs, out, ZipUtils.Options(includeRoot = includeRoot, overwrite = overwrite))
        Log.i(TAG, "Zip OK: ${out.absolutePath}")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "ZipHeadless", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun showDone(msg: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val done = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("ZipHeadless")
            .setContentText(msg)
            .setAutoCancel(true)
            .build()
        nm.notify(2, done)
    }
}
