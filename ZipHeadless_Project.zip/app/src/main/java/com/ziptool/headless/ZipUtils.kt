package com.ziptool.headless

import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipUtils {

    data class Options(
        val includeRoot: Boolean = false,
        val overwrite: Boolean = true,
        val followSymlinks: Boolean = false
    )

    @Throws(IOException::class)
    fun zip(inputs: List<File>, outputZip: File, options: Options = Options()) {
        if (outputZip.exists()) {
            if (options.overwrite) outputZip.delete()
            else throw IOException("Arquivo de saída já existe: ${outputZip.absolutePath}")
        }

        outputZip.parentFile?.let { if (!it.exists()) it.mkdirs() }

        FileOutputStream(outputZip).use { fos ->
            BufferedOutputStream(fos).use { bos ->
                ZipOutputStream(bos).use { zos ->
                    inputs.forEach { input ->
                        if (!input.exists()) return@forEach
                        val basePath = if (input.isDirectory && options.includeRoot)
                            input.parentFile!!.absoluteFile.toPath()
                        else
                            input.absoluteFile.toPath()
                        addFileToZip(zos, input, basePath, options.includeRoot)
                    }
                }
            }
        }
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, basePath: java.nio.file.Path, includeRoot: Boolean) {
        if (file.isDirectory) {
            val children = file.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
            if (includeRoot && children.isEmpty()) {
                val entryName = basePath.relativize(file.absoluteFile.toPath()).toString().replace(File.separatorChar, '/') + "/"
                zos.putNextEntry(ZipEntry(entryName))
                zos.closeEntry()
            }
            children.forEach { child ->
                addFileToZip(zos, child, basePath, includeRoot)
            }
        } else {
            val rel = basePath.relativize(file.absoluteFile.toPath()).toString().replace(File.separatorChar, '/')
            val entryName = if (includeRoot) rel else rel.substringAfter('/', rel)
            if (entryName.isBlank()) return
            FileInputStream(file).use { fis ->
                BufferedInputStream(fis).use { bis ->
                    val entry = ZipEntry(entryName)
                    entry.time = file.lastModified()
                    zos.putNextEntry(entry)
                    val buffer = ByteArray(64 * 1024)
                    var read: Int
                    while (bis.read(buffer).also { read = it } != -1) {
                        zos.write(buffer, 0, read)
                    }
                    zos.closeEntry()
                }
            }
        }
    }
}
